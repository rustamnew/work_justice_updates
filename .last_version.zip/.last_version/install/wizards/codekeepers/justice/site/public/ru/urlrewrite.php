<?php
$arUrlRewrite=array (
  1 => 
  array (
    'CONDITION' => '#^/services/#',
    'RULE' => '',
    'ID' => 'bitrix:news',
    'PATH' => '/services/index.php',
    'SORT' => 100,
  ),
  7 => 
  array (
    'CONDITION' => '#^/projects/#',
    'RULE' => '',
    'ID' => 'bitrix:news',
    'PATH' => '/projects/index.php',
    'SORT' => 100,
  ),
  8 => 
  array (
    'CONDITION' => '#^/career/#',
    'RULE' => '',
    'ID' => 'bitrix:news',
    'PATH' => '/career/index.php',
    'SORT' => 100,
  ),
  0 => 
  array (
    'CONDITION' => '#^/rest/#',
    'RULE' => '',
    'ID' => NULL,
    'PATH' => '/bitrix/services/rest/index.php',
    'SORT' => 100,
  ),
  10 => 
  array (
    'CONDITION' => '#^/team/#',
    'RULE' => '',
    'ID' => 'bitrix:news',
    'PATH' => '/team/index.php',
    'SORT' => 100,
  ),
  12 => 
  array (
    'CONDITION' => '#^/shop/#',
    'RULE' => '',
    'ID' => 'bitrix:news',
    'PATH' => '/shop/index.php',
    'SORT' => 100,
  ),
  13 => 
  array (
    'CONDITION' => '#^/blog/#',
    'RULE' => '',
    'ID' => 'bitrix:news',
    'PATH' => '/blog/index.php',
    'SORT' => 100,
  ),
);
