<?
$MESS ['ROOT_MENU_TYPE_TIP'] = "Select here one of the existing menu types. If you select <b><i>(other)</i></b>, you will have to specify the menu in the field beside.";
$MESS ['MAX_LEVEL_TIP'] = "An integer from 1 to 4. Specifies the maximun menu nesting level. Values other than 1 are valid only for multi-level menu templates.";
$MESS ['CHILD_MENU_TYPE_TIP'] = "Similar to the root menu type, but defines the menu type for other levels.";
$MESS ['USE_EXT_TIP'] = "If checked, the system will try to find a file <b><i>.menu_type.</i>menu_ext.php</b> in each section when including a menu. This file specifies an array of parameters that define the menu items.";
?>