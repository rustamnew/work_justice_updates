<?
$MESS["T_IBLOCK_DESC_CATALOG"] = "Catalog";
$MESS["IBLOCK_SECTIONS_TOP_2_TEMPLATE_NAME"] = "Sections list";
$MESS["IBLOCK_SECTIONS_TOP_2_TEMPLATE_DESCRIPTION"] = "Displays the information block sections with total number of elements for each section";
?>