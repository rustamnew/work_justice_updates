<?
$MESS["SEARCH_CHECK_DATES"] = "Search only unexpired documents";
$MESS["SEARCH_SORT"] = "Rank tags";
$MESS["SEARCH_NAME"] = "By name";
$MESS["SEARCH_CNT"] = "By frequency";
$MESS["SEARCH_PAGE_ELEMENTS"] = "Number of tags";
$MESS["SEARCH_PERIOD"] = "Show tags within (days)";
$MESS["SEARCH_URL_SEARCH"] = "Path to search page (relative to site root)";
$MESS["SEARCH_TAGS_INHERIT"] = "Narrow search area";
$MESS["CP_BSTC_FILTER_NAME"] = "Extra Filter";
?>