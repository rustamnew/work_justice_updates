<?
$MESS ['BSF_T_SEARCH_BUTTON'] = "Search";
?>