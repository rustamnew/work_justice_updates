<?
$MESS ['SEARCH_FORM_NAME'] = "Search form";
$MESS ['SEARCH_FORM_DESC'] = "The search form to include into the site design.";
$MESS ['SEARCH_SERVICE'] = "Search";
?>