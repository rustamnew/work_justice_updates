<?
$MESS ['SEARCH_FORM_PAGE'] = "Search results page (#SITE_DIR# macro is available)";
?>
